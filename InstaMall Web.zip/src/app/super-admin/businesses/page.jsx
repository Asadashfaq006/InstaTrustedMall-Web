'use client';

import { useEffect, useState } from 'react';
import { Building2, Loader2, Users, Package, Key } from 'lucide-react';

const API_BASE = '/api';

export default function BusinessesPage() {
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetch_() {
      try {
        const res = await fetch(`${API_BASE}/super-admin/businesses`, { credentials: 'include' });
        const data = await res.json();
        if (data.success) setBusinesses(data.data);
      } catch (err) {
        console.error('Failed:', err);
      } finally {
        setLoading(false);
      }
    }
    fetch_();
  }, []);

  const planBadge = (plan) => {
    const styles = {
      starter: 'bg-slate-100 text-slate-700',
      professional: 'bg-indigo-100 text-indigo-700',
      enterprise: 'bg-violet-100 text-violet-700',
    };
    return (
      <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${styles[plan] || styles.starter}`}>
        {plan ? plan.charAt(0).toUpperCase() + plan.slice(1) : 'No Plan'}
      </span>
    );
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-900">All Businesses</h1>
        <p className="text-slate-500 mt-1">Manage all registered businesses on the platform</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-slate-400" />
        </div>
      ) : businesses.length === 0 ? (
        <div className="bg-white rounded-xl p-12 shadow-sm border border-slate-100 text-center">
          <Building2 className="h-12 w-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500">No businesses registered yet</p>
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Business</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Owner</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Type</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Plan</th>
                <th className="text-center px-6 py-3 font-medium text-slate-500">Users</th>
                <th className="text-center px-6 py-3 font-medium text-slate-500">Products</th>
                <th className="text-left px-6 py-3 font-medium text-slate-500">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {businesses.map((b) => (
                <tr key={b.id} className="hover:bg-slate-50 transition">
                  <td className="px-6 py-4">
                    <div className="font-medium text-slate-900">{b.name}</div>
                  </td>
                  <td className="px-6 py-4 text-slate-600">
                    {b.admin_name || '—'}
                    {b.admin_email && <div className="text-xs text-slate-400">{b.admin_email}</div>}
                  </td>
                  <td className="px-6 py-4 text-slate-600 capitalize">{b.type}</td>
                  <td className="px-6 py-4">{planBadge(b.plan)}</td>
                  <td className="px-6 py-4 text-center text-slate-600">{b.user_count || 0}</td>
                  <td className="px-6 py-4 text-center text-slate-600">{b.product_count || 0}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${b.is_active ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>
                      {b.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
