'use client';
import '@/lib/webElectronApi';
/**
 * Client-side providers: Tooltip, Toast, Auth gate, Scanner, Shortcuts.
 * This mirrors the old App.jsx logic minus React Router.
 *
 * Auth flow:
 * 1. Platform auth (JWT) — checked via usePlatformAuthStore
 * 2. Per-business PIN auth — existing flow for business dashboard users
 */
import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import useBusinessStore from '@/stores/businessStore';
import useAuthStore from '@/stores/authStore';
import usePlatformAuthStore from '@/stores/platformAuthStore';
import { applyBusinessTheme } from '@/constants/businessThemes';
import LoginScreen from '@/screens/LoginScreen';
import AppLockOverlay from '@/components/auth/AppLockOverlay';
import KeyboardShortcutsHelp from '@/components/KeyboardShortcutsHelp';
import { createShortcutListener } from '@/utils/keyboardShortcuts';

export default function Providers({ children }) {
  const router = useRouter();
  const pathname = usePathname();

  const { activeBusiness, loadAll, loadActive } = useBusinessStore();
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const isLocked = useAuthStore((s) => s.isLocked);
  const currentUser = useAuthStore((s) => s.currentUser);
  const lock = useAuthStore((s) => s.lock);
  const touch = useAuthStore((s) => s.touch);

  const [initialized, setInitialized] = useState(false);
  const [hasUsers, setHasUsers] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const autoLockRef = useRef(null);
  const autoLockMinutesRef = useRef(0);
  const [showShortcutsHelp, setShowShortcutsHelp] = useState(false);

  // Adapt navigate for Next.js
  const navigate = useCallback((path) => router.push(path), [router]);

  // Global keyboard shortcuts
  useEffect(() => {
    const listener = createShortcutListener(navigate);
    listener.attach();
    const handleShowHelp = () => setShowShortcutsHelp(true);
    window.addEventListener('shortcut:show-help', handleShowHelp);
    return () => {
      listener.detach();
      window.removeEventListener('shortcut:show-help', handleShowHelp);
    };
  }, [navigate]);

  // Initialize app — batch both calls in parallel
  useEffect(() => {
    const init = async () => {
      try {
        await Promise.all([loadAll(), loadActive()]);
      } catch (_) {}
      setInitialized(true);
    };
    init();
  }, []);

  // Check if business has users (auth required)
  useEffect(() => {
    if (!initialized || !activeBusiness) {
      setAuthChecked(true);
      return;
    }
    const checkAuth = async () => {
      try {
        const result = await window.electronAPI.users.hasUsers(activeBusiness.id);
        setHasUsers(result.success && result.data);

        const settingsResult = await window.electronAPI.authSettings.get(activeBusiness.id);
        if (settingsResult.success) {
          autoLockMinutesRef.current = settingsResult.data.auto_lock_after_minutes || 0;
        }
      } catch {
        setHasUsers(false);
      }
      setAuthChecked(true);
    };
    checkAuth();
  }, [initialized, activeBusiness?.id]);

  // Navigate when business state changes
  // Don't redirect away from public pages (landing, welcome)
  useEffect(() => {
    if (initialized) {
      if (!activeBusiness && pathname !== '/welcome' && pathname !== '/') {
        router.replace('/welcome');
      }
    }
  }, [initialized, activeBusiness, pathname, router]);

  // Apply per-business-type theme
  useEffect(() => {
    if (activeBusiness?.type) {
      applyBusinessTheme(activeBusiness.type);
    }
  }, [activeBusiness?.type]);

  // Auto-lock timer
  const resetAutoLock = useCallback(() => {
    touch();
    if (autoLockRef.current) clearTimeout(autoLockRef.current);
    const minutes = autoLockMinutesRef.current;
    if (minutes > 0 && isAuthenticated && !isLocked) {
      autoLockRef.current = setTimeout(() => {
        lock();
      }, minutes * 60 * 1000);
    }
  }, [isAuthenticated, isLocked, touch, lock]);

  useEffect(() => {
    if (!isAuthenticated || isLocked) return;
    const events = ['mousedown', 'keydown', 'mousemove', 'scroll', 'touchstart'];
    events.forEach((e) => window.addEventListener(e, resetAutoLock, { passive: true }));
    resetAutoLock();
    return () => {
      events.forEach((e) => window.removeEventListener(e, resetAutoLock));
      if (autoLockRef.current) clearTimeout(autoLockRef.current);
    };
  }, [isAuthenticated, isLocked, resetAutoLock]);

  // Public pages don't need auth or business initialization
  const isPublicPage = pathname === '/' || pathname === '/welcome';
  const isPlatformPage = pathname.startsWith('/super-admin') || pathname.startsWith('/admin');

  // Check platform auth session on mount for platform pages
  const platformAuth = usePlatformAuthStore();
  useEffect(() => {
    if (isPlatformPage && !platformAuth.isAuthenticated) {
      platformAuth.checkSession();
    }
  }, [isPlatformPage]);

  // Loading splash (skip for public landing page and platform pages)
  if (!isPublicPage && !isPlatformPage && (!initialized || !authChecked)) {
    return (
      <TooltipProvider>
        <div className="h-screen flex items-center justify-center bg-background">
          <div className="text-center">
            <h1 className="font-display text-3xl mb-2">
              <span className="text-accent font-bold">Insta</span>
              <span className="text-navy font-bold">Mall</span>
            </h1>
            <p className="text-text-muted text-sm">Loading...</p>
          </div>
        </div>
      </TooltipProvider>
    );
  }

  // Auth gate: show login if business has users but not authenticated
  // Skip for public pages (landing, welcome) and platform pages (super-admin, admin)
  if (activeBusiness && hasUsers && !isAuthenticated && !isPublicPage && !isPlatformPage && pathname !== '/welcome') {
    return (
      <TooltipProvider>
        <LoginScreen />
        <Toaster />
      </TooltipProvider>
    );
  }

  // Lock overlay
  if (isLocked && isAuthenticated) {
    return (
      <TooltipProvider>
        <AppLockOverlay />
        <Toaster />
      </TooltipProvider>
    );
  }

  return (
    <TooltipProvider>
      {children}
      <Toaster />
      <KeyboardShortcutsHelp open={showShortcutsHelp} onOpenChange={setShowShortcutsHelp} />
    </TooltipProvider>
  );
}
