/**
 * Module 8: Login Screen
 * Full-screen auth overlay with user selection and PIN entry.
 * Flow: Select user → Enter PIN → Authenticated
 */
import React, { useState, useEffect } from 'react';
import { Shield } from 'lucide-react';
import useAuthStore from '@/stores/authStore';
import useBusinessStore from '@/stores/businessStore';
import PinPad from '@/components/auth/PinPad';
import UserAvatar from '@/components/auth/UserAvatar';
import { ROLE_LABELS, ROLE_COLORS } from '@/constants/roles';
import { cn } from '@/lib/utils';

export default function LoginScreen() {
  const { login } = useAuthStore();
  const activeBusiness = useBusinessStore((s) => s.activeBusiness);

  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [pageLoading, setPageLoading] = useState(true);

  useEffect(() => {
    if (!activeBusiness) return;
    loadUsers();
  }, [activeBusiness?.id]);

  const loadUsers = async () => {
    setPageLoading(true);
    try {
      const result = await window.electronAPI.users.getAll(activeBusiness.id);
      if (result.success) {
        const active = result.data.filter((u) => u.is_active);
        setUsers(active);
        // If only 1 user, auto-select them
        if (active.length === 1) setSelectedUser(active[0]);
      }
    } catch (err) {
      console.error('Failed to load users', err);
    } finally {
      setPageLoading(false);
    }
  };

  const handleSubmitPin = async (pin) => {
    if (!selectedUser || !activeBusiness) return;
    setLoading(true);
    setError('');
    try {
      const result = await window.electronAPI.auth.login({
        businessId: activeBusiness.id,
        username: selectedUser.username,
        pin,
      });
      if (result.success) {
        login(result.data);
      } else {
        setError(result.error === 'invalid_credentials' ? 'Wrong PIN' : result.error);
      }
    } catch {
      setError('Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    setSelectedUser(null);
    setError('');
  };

  if (pageLoading) {
    return (
      <div className="h-screen w-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center">
        <p className="text-white/50 text-sm">Loading...</p>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex flex-col items-center justify-center overflow-auto">
      {/* Logo */}
      <div className="mb-8 text-center">
        <h1 className="font-display text-3xl tracking-tight mb-1">
          <span className="text-indigo-400 font-bold">Insta</span>
          <span className="text-white font-bold">Mall</span>
        </h1>
        {activeBusiness && (
          <p className="text-white/40 text-sm">{activeBusiness.name}</p>
        )}
      </div>

      {/* PIN Entry for selected user */}
      {selectedUser ? (
        <div className="flex flex-col items-center">
          <UserAvatar
            displayName={selectedUser.display_name}
            avatarColor={selectedUser.avatar_color}
            size="xl"
            className="mb-3"
          />
          <h2 className="text-white text-xl font-semibold mb-1">{selectedUser.display_name}</h2>
          <span className={cn(
            'text-xs px-2 py-0.5 rounded-full mb-6',
            ROLE_COLORS[selectedUser.role]?.bg,
            ROLE_COLORS[selectedUser.role]?.text,
          )}>
            {ROLE_LABELS[selectedUser.role] || selectedUser.role}
          </span>

          <PinPad
            pinLength={selectedUser.pin_length || 4}
            onSubmit={handleSubmitPin}
            error={error}
            disabled={loading}
          />

          {users.length > 1 && (
            <button
              onClick={handleBack}
              className="mt-6 text-sm text-white/40 hover:text-white/70 transition-colors"
            >
              ← Switch user
            </button>
          )}
        </div>
      ) : (
        /* User selection grid */
        <div className="flex flex-col items-center max-w-lg w-full px-6">
          <div className="flex items-center gap-2 mb-6">
            <Shield className="w-5 h-5 text-accent" />
            <h2 className="text-white text-lg font-medium">Who's using InstaMall?</h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 w-full">
            {users.map((user) => (
              <button
                key={user.id}
                onClick={() => setSelectedUser(user)}
                className="flex flex-col items-center gap-2 p-4 rounded-xl bg-white/5 hover:bg-white/10 
                           transition-all border border-white/5 hover:border-accent/30"
              >
                <UserAvatar
                  displayName={user.display_name}
                  avatarColor={user.avatar_color}
                  size="lg"
                />
                <span className="text-white text-sm font-medium truncate max-w-full">
                  {user.display_name}
                </span>
                <span className={cn(
                  'text-[10px] px-1.5 py-0.5 rounded-full',
                  ROLE_COLORS[user.role]?.bg,
                  ROLE_COLORS[user.role]?.text,
                )}>
                  {ROLE_LABELS[user.role]}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
